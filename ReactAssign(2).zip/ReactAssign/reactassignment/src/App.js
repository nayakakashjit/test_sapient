import React from 'react';
import logo from './logo.svg';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import ProductList from './Products/product';

function App() {
  return (
    <div className="App">
        <ProductList/>
    </div>
  );
}

export default App;
